package com.example.womenapp;

import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

public class ContactsAdapter extends RecyclerView.Adapter<ContactsAdapter.ContactViewHolder> {

    private Cursor cursor;
    private DatabaseHelper db;

    // Constructor to accept the Cursor and DatabaseHelper instance
    public ContactsAdapter(Cursor cursor, DatabaseHelper db) {
        this.cursor = cursor;
        this.db = db;
    }

    @Override
    public ContactViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_item, parent, false);
        return new ContactViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ContactViewHolder holder, int position) {
        if (cursor != null && cursor.moveToPosition(position)) {
            try {
                // Safely get column indexes
                int nameIndex = cursor.getColumnIndexOrThrow(DatabaseHelper.COL_NAME);
                int phoneIndex = cursor.getColumnIndexOrThrow(DatabaseHelper.COL_PHONE);
                int contactIdColumnIndex = cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ID);

                String name = cursor.getString(nameIndex);
                String phone = cursor.getString(phoneIndex);
                String contactId = cursor.getString(contactIdColumnIndex);

                holder.contactName.setText(name);
                holder.contactPhone.setText(phone);

                // Set delete button click listener
                holder.btnDelete.setOnClickListener(v -> {
                    // Make sure the contact is deleted only
                    if (db.deleteContact(contactId)) {
                        // After deletion, refresh the RecyclerView data
                        Cursor updatedCursor = db.getAllContacts();
                        updateData(updatedCursor);
                        Toast.makeText(v.getContext(), "Contact Deleted", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(v.getContext(), "Failed to Delete", Toast.LENGTH_SHORT).show();
                    }
                });
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
                Toast.makeText(holder.itemView.getContext(), "Error loading contact", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public int getItemCount() {
        return cursor != null ? cursor.getCount() : 0;
    }

    // Update the data in RecyclerView after deletion
    public void updateData(Cursor newCursor) {
        this.cursor = newCursor;
        notifyDataSetChanged();
    }

    public static class ContactViewHolder extends RecyclerView.ViewHolder {
        TextView contactName, contactPhone;
        Button btnDelete;

        public ContactViewHolder(View itemView) {
            super(itemView);
            contactName = itemView.findViewById(R.id.contactName);
            contactPhone = itemView.findViewById(R.id.contactPhone);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }
}
