package com.example.womenapp;

import android.database.sqlite.SQLiteDatabase;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.womenapp.DatabaseHelper;
import com.example.womenapp.R;
public class ContactsActivity extends AppCompatActivity {
    EditText etName, etPhone;
    Button btnSave;
    DatabaseHelper db;
    RecyclerView recyclerView;
    ContactsAdapter contactsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contacts);

        etName = findViewById(R.id.etName);
        etPhone = findViewById(R.id.etPhone);
        btnSave = findViewById(R.id.btnSave);
        recyclerView = findViewById(R.id.recyclerView);
        db = new DatabaseHelper(this);

        // Set up RecyclerView with an adapter
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initially load all contacts
        Cursor initialCursor = db.getAllContacts();
        contactsAdapter = new ContactsAdapter(initialCursor, db); // Pass db to the adapter
        recyclerView.setAdapter(contactsAdapter);

        btnSave.setOnClickListener(view -> {
            String name = etName.getText().toString();
            String phone = etPhone.getText().toString();

            if (name.isEmpty() || phone.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            } else {
                if (db.addContact(name, phone)) {
                    Toast.makeText(this, "Contact Saved", Toast.LENGTH_SHORT).show();
                    etName.setText("");
                    etPhone.setText(""); // Clear fields after saving

                    // Refresh the data in the RecyclerView
                    Cursor updatedCursor = db.getAllContacts();
                    contactsAdapter.updateData(updatedCursor); // Update RecyclerView with new cursor data
                } else {
                    Toast.makeText(this, "Failed to Save", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}


