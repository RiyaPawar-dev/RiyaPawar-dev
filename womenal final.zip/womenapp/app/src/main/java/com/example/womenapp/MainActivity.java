package com.example.womenapp;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.telephony.SmsManager;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
    Button btnAddContacts, btnEmergencyCall;
    DatabaseHelper db;
    private static final int REQUEST_CALL_PERMISSION = 1;
    private static final int REQUEST_LOCATION_PERMISSION = 2;

    ImageView btnHelpMe;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnHelpMe = findViewById(R.id.btnSOS);
        Animation blinkAnimation = AnimationUtils.loadAnimation(this, R.anim.blink_animation);
        btnHelpMe.startAnimation(blinkAnimation);
        btnAddContacts = findViewById(R.id.btnAddContacts);
        btnEmergencyCall = findViewById(R.id.btnEmergencyCall);
        db = new DatabaseHelper(this);

        // Check and request permissions if not granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL_PERMISSION);
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_PERMISSION);
        }

        btnHelpMe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendAlertMessage();
            }
        });

        btnEmergencyCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makeEmergencyCall();
            }
        });

        btnAddContacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ContactsActivity.class);
                startActivity(intent);
            }
        });
    }

    private void sendAlertMessage() {
        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_LOCATION_PERMISSION);
            return;
        }

        Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
        String locationText = "Emergency! Please help!\n Location not available.";
        if (location != null) {
            double latitude = location.getLatitude();
            double longitude = location.getLongitude();
            locationText = "Emergency! \n Please help! \n My Current location: https://maps.google.com/?q=" + latitude + "," + longitude;
        }

        Cursor res = db.getAllContacts();
        if (res.getCount() == 0) {
            Toast.makeText(this, "No emergency contacts found", Toast.LENGTH_SHORT).show();
            return;
        }
        while (res.moveToNext()) {
            int phoneIndex = res.getColumnIndex("PHONE");
            if (phoneIndex != -1) {
                String phoneNumber = res.getString(phoneIndex);
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(phoneNumber, null, locationText, null, null);
            }
        }
        Toast.makeText(this, "Alert messages sent with location!", Toast.LENGTH_SHORT).show();
    }

    private void makeEmergencyCall() {
        Cursor res = db.getAllContacts();
        if (res.getCount() == 0) {
            Toast.makeText(this, "No emergency contacts found", Toast.LENGTH_SHORT).show();
            return;
        }

        while (res.moveToNext()) { // Loop to find the first valid number
            int phoneIndex = res.getColumnIndex("PHONE");
            if (phoneIndex != -1) {
                String phoneNumber = res.getString(phoneIndex);
                if (phoneNumber != null && phoneNumber.matches("\\d{10}")) { // Ensure it's exactly 10 digits
                    Intent callIntent = new Intent(Intent.ACTION_CALL);
                    callIntent.setData(Uri.parse("tel:" + phoneNumber));
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                        startActivity(callIntent);
                    } else {
                        Toast.makeText(this, "Call permission not granted", Toast.LENGTH_SHORT).show();
                    }
                    return; // Exit after calling the first valid number
                }
            }
        }

        Toast.makeText(this, "No valid 10-digit phone number found", Toast.LENGTH_SHORT).show();
    }
}