package com.example.womenapp;

public class AdminActivity {
}
